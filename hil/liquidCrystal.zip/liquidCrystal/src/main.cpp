#include <Arduino.h>
#include <LiquidCrystal.h>

LiquidCrystal lcd(5, 8, 10, 11, 12, 13);

const int led = 14;
const int pb = 15; 

bool pbState;
bool ledState = LOW; //led active low
bool pbLastState = HIGH; //button not pressed
int scrollIndex = 0;
unsigned long interval = 600; //blinking interval
unsigned long scrollInt = 300; //scrolling interval
unsigned long curr, prev = 0;

String message1 = "         Yī yīn yī yáng zhī wèi dào SUSHI DONT LIE";
String message2 = "         Míng mǎ biāo jià de nà xiē wù fēi hēi jí bái";
String message3 = "BOOM";

void setup() {
  Serial.begin(115200);
  lcd.begin(16, 2);
  lcd.clear();
  lcd.setCursor(5,1);
  lcd.write("SKAI IS");
  lcd.setCursor(4, 2);
  lcd.write("YOUR GOD");
  pinMode(led, OUTPUT);
  pinMode(pb, INPUT_PULLUP);
}

void blinkingLED(){
    if(curr - prev >= interval){
      ledState = !ledState;
      digitalWrite(led, ledState);
      prev = curr;
    } else {
    ledState = LOW; //turn off the led
    digitalWrite(led, ledState);
  }
}

void scrollMessage(String message){
  if (curr - prev >= scrollInt){
    prev = curr;
    lcd.setCursor(0, 0); //cursor ke bagian awal
    String display = message.substring(scrollIndex); //bagian pertama dari string
    if (display.length() < 16){
      display += "                "; //tambahkan spasi
    }
    lcd.print(display.substring(0, 16)); //tampilkan 16 karakter
    scrollIndex++;
    if(scrollIndex >= message.length()){
      scrollIndex = 0;
    }
  }
}

void loop() {
 curr = millis();
 pbState = digitalRead(pb);
 
 if (pbState == HIGH && pbLastState == HIGH){ //pb not yet pressed
  digitalWrite(led, LOW); //turn off led
  scrollMessage(message1);
 } else if (pbState == LOW && pbLastState == HIGH){ //pb was pressed
  digitalWrite(led, LOW); // turn off led
  scrollMessage(message2);
 } else { // pb is pressed
  blinkingLED();
  lcd.clear();
  lcd.setCursor(6, 1);
  lcd.print(message3);
 }
 pbLastState = pbState; //update state pushbutton
}
